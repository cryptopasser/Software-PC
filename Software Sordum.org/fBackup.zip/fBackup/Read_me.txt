Author: BlueLife , Velociraptor
www.sordum.org

[010101010101010101]--Simple Firefox Backup v1.2--[010101010101010101]

(February 19, 2020)
------------
Changelog:
1. [ADDED] - Portable Firefox Support
2. [ADDED] - File - "Firefox links" feature reads from .ini file
3. [ADDED] - Ability to open the backup folder from the action menu

[010101010101010101]--Simple Firefox Backup v1.1--[010101010101010101]

(January 25, 2020)
------------
Changelog:
1. [ADDED] - Command prompt Support
2. [ADDED] - Plugin backup option
3. [ADDED] - Firefox Links option (Under File menu)

[010101010101010101]--Simple Firefox Backup v1.0--[010101010101010101]

(January 20, 2020)
-------------
Simple Firefox Backup� is a portable Freeware Tool that will help you easily create 
back-up copies of your Mozilla Firefox data . The software is an automated version 
of the manual method