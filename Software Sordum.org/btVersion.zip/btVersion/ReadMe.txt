Author: BlueLife , Velociraptor 
www.sordum.org

###################-- Bluetooth Version finder v1.2 --###################
(Sunday, 23 May 2021) 

What is new:
[ ADDED ] – Menu option
[ ADDED ] – F5 keyboard shortcut
[ FIXED ] – Some minor bugs (Most of the codes have been updated)

###################-- Bluetooth Version finder v1.1 --###################
(Thursday, 9 April 2020) 

What is new:
[ FIXED ] – Bluetooth Version finder doesn’t detect Latest Bluetooth versions


###################-- Bluetooth Version finder v1.0 --###################
(Tuesday, June 5 2018) 

Finding Bluetooth verison manually through the graphical user interface would be time consuming, 
tedious and, prone to human error therefore we have coded a portable Freeware “Bluetooth Version finder”.
It is the easiest method to find the Bluetooth version number.