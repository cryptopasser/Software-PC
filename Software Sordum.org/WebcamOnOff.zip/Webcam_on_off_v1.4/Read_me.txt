Author: BlueLife , Velociraptor
www.sordum.org

####################--WEbCam On - Off v1.4--####################
(Friday 4 December 2020)

1.[Fixed] � WebCam On-Off Doesn�t Work on Windows 10 20H2 Properly
2.[Fixed] � GUI is too small (New GUI)
3.[Fixed] � It Doesn't show the Name of the Webcam in List
4.[Added] � Language support
5.[Added] � Block WebCam Feature - Win10 support only
6.[Added] � Block Microphone Feature - Win10 support only
7.[Added] � Open Webcam and Microphone Privacy settings - Win10 support only
8.[Added] � Change Webcam Preview dimansion via drag - Win10 support only


####################--WEbCam On - Off v1.3--####################
(06.11.2017)

1.[Fixed] � WebCam On-Off Doesn�t Work on Windows 10 1709
2.[Fixed] � GUI minor bugs

####################--WEbCam On - Off v1.2--####################
(Wednesday, 14. January 2015)

[improved] - Webcam preview screen and settings button design
[Added] - P (preview) Parameter for Cmd command


####################--WEbCam On - Off v1.1--####################
(Sunday, 30. November 2014)


[Added] - Improved Webcam device selection function and drive status indicator
[Added] - Webcam preview function
[Added] - Webcam picture save function
[Added] - Webcam zoom im - out function
 

####################--WEbCam On - Off v1.0--####################
(Friday, 21. November 2014)

It is a Portable Freeware to easily disable or Enable your Webcam device
It has Cmd support too , to learn it's all commands please use WebCam.exe /? command

WebCam_OFF code:
----------------
@Echo Off

Start WebCam.exe /OFF


WebCam_ON Code:
----------------
@Echo Off

Start WebCam.exe /ON


