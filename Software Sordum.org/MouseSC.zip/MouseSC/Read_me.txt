Author: BlueLife , Velociraptor
www.sordum.org

[###################]--Net Disabler v1.1--[###################]

(Monday, 19 April 2021)
------------
Changelog:

1.[FIXED] - A small typo
2.[ADDED] - /Query parameter

[###################]--Net Disabler v1.0--[###################]

(Tuesday, October 27, 2020)
------------
First release, Mouse settings changer is a Portable freeware Application to help you change mouse settings without open Mouse Properties dialog box , it has no GUI.