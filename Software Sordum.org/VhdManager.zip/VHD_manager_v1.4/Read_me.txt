Author: BlueLife , Velociraptor
www.sordum.org

================ -- Simple VHD Manager v1.4 -- ================
(Thursday, January 02, 2020)

Changelog:

1. [FIXED] - Vhdx Allocation unit size error (doesn't format newly created VHD/VHDX)
2. [FIXED] - VHD automount doesn't work Properly after Windows startup (Additional controls added)
3. [FIXED] - Under "Add file" feature Can't choose ISO file
4. [FIXED] - GUI Buttons are small and not clear
5. [FIXED] - Some BUGs  
6. [ADDED] - x64-bit version
7. [ADDED] - Boot Menu Policy (Legacy-Standard) Choice feature
8. [ADDED] - New grub4dos version , which uses to run the iso file from the boot menu


================ -- Simple VHD Manager v1.3 -- ================
(Thursday, July 14, 2016)

Changelog:

1. [ Fixed ] - After detach and remove any Vhd/Vhdx file from the list, it is impossible to Attach current listed one
2. [ Fixed ] - False positive Issue
3. [ Fixed ] - Minor code corrections

================ -- Simple VHD Manager v1.2 -- ================
(Monday, January 25, 2016)

Changelog:

1. [ Fixed ] - Can not create big VHd - VHDX files (Critical)


================ -- Simple VHD Manager v1.1 -- ================
(Thursday, January 21, 2016)

Changelog:

1. [ Fixed ] - After booting from VHD it is possible to change system drive letter.
2. [ Fixed ] - Attach marked to system startup feature doesn't work properly
3. [ Added ] - Create a VHD - VHDX Feature
4. [ Added ] - Right click menu options for vhd-vhdx-iso (Context menu or send to) 
5. [ Fixed ] - Minor code corrections and improvements


================ -- Simple VHD Manager v1.0 -- ================
(Wednesday, September 16, 2015)

Simple VHD Manager is portable freeware which helps users simplify some VHD - VHDX - ISO operations

� You can attach and detach VHD/VHDX/ISO files via drag and drop
� You can permanently attach a virtual hard disk in Windows 10 , Windows 8,1 , Windos 8, Windows 7
� You can easily add and/or remove VHD/VHDX/ISO files to the boot menu.
