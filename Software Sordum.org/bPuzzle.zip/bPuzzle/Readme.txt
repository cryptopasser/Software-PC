Author: BlueLife
www.sordum.org

---------------- Bpuzzle v1.2 ---------------------
Tuesday, 13 April 2021

Changelog:

1. [Added] - Png format Support (only support 800x600 px)
2. [Added] - show image option in bottom right corner
3. [Added] - x64 version
4. [Fixed] - The playing Screen is too small (Game screen has been enlarged to 800x600 px)
5. [Fixed] - Some minor Bugs
6. [Fixed] - False Positive Issue


---------------- Bpuzzle v1.1 ---------------------
(Tuesday, 21 January 2014)

Changelog:

1. [Added] - Keyboard Arrow key support (to play the Game You can use Arrow keys on the keyboard)
2. [Fixed] - Some minor Bugs
3. [Fixed] - False Positive Issue


---------------- Bpuzzle v1.0 ---------------------

Thursday, 11 April 2013

bPuzzle is a simple game which can be played by moving puzzle pieces one place to another.
It has 5 difficulty levels.