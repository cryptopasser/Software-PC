Author: BlueLife , Velociraptor
www.sordum.org

###################--BlueLife Hosts Editor v1.3--###################
(Sunday, march 7, 2021)

Changelog:
[ Added ] – Option for different Time Server. Can be manually corrected from UpdateTime.ini
[ Added ] – Options menu for various settings
[ Added ] – Option to set up service to correct the Date & time on system startup
[ Added ] – x64 version
[ Fixed ] - Some Coding weaknesses

###################--BlueLife Hosts Editor v1.2--###################
(Sunday, October 30, 2016)

Changelog:
[ Fixed ] – False positives

###################--BlueLife Hosts Editor v1.1--###################
(Saturday, 4 june 2016)

Changelog:
[ Fixed ] – A small Bug fixed

###################--BlueLife Hosts Editor v1.0--###################
(Wednesday, November 20, 2013)

First release, a Small portable Application to fix Windows Date & Time


