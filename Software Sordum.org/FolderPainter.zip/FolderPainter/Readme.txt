Author: BlueLife, Velociraptor
www.sordum.org

#################--Folder Painter v1.3--#################
(Tuesday, january 19, 2021) - What is New

1.[ADDED] - Sub folder support added. Limit can be set from "SubfolderCount = -1" line in "Icons\FolderPainter.ini" file
1.[ADDED] - Refresh options from .ini file
2.[FIXED] - Font in main interface is too small
3.[FIXED] - If I change the icon,Folder change date is changing (In this version,Folder change date remain the same)
4.[FIXED] - Some minor Bugs

#################--Folder Painter v1.2--#################
(Sunday, April 07, 2019) - What is New

1.[Fixed] � Restore default Folder option doesn�t remove the �desktop.ini� file in the folder

#################--Folder Painter v1.1--#################
(Thursday, March 21, 2019) - Whats New

1.[ADDED] � Multiple theme support for the Context menu
2.[ADDED] � Number of colored icons increased from 14 to 294
3.[ADDED] � Icon personalization is simplified
4.[ADDED] � x64 version


#################--Folder Painter v1.0--#################
(Monday, September 11, 2017)

Folder Painter is a Portable freeware that lets you change the folders color and revert it back. 

