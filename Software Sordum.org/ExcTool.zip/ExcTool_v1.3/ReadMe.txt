Author: BlueLife, Velociraptor
www.sordum.org

####################--Defender Exclusion Tool v1.3--####################

Thursday, 09. September 2021 , What is New

1. [Fixed] � Defender Exclusion Tool Doesn't work on Windows 11
2. [Added] - Some code improvements

####################--Defender Exclusion Tool v1.2--####################

Friday, 04. June 2021 , What is New

1. [Added] - Language support
2. [Added] - Expor/Import feature
3. [Added] - Option to show all windows defender exclusions (include group policy)
4. [Removed] - CMD Parameter support (For security reason)
5. [Added] � Some minor improvements
6. [Fixed] � Defender Injector sounds like the program is doing something malicious (Name changed)

####################--Defender Injector v1.1--####################
		
Monday , 14. January 2019 , What is New

1. [Fixed] �  Launch Defender feature doesn�t work on Windows 10 1809

####################--Defender Injector v1.0--####################

Sunday, 22. April 2018 , What is New

First Release , A small portable tool for adding exceptions to Microsoft Windows defender

