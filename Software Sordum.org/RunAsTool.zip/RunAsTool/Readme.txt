Author: BlueLife , Velociraptor 
www.sordum.org

@@@@@@@@@@@@@@@@@@@@--RunAsTool v1.4--@@@@@@@@@@@@@@@@@@@@
(Tuesday, 2. November 2018)

1. [Fixed] - Import parameter doesn't work on standard user
2. [Fixed] - Minor BUGs
3. [Added] - Standard user can resize the program GUI (With Mouse)

@@@@@@@@@@@@@@@@@@@@--RunAsTool v1.3--@@@@@@@@@@@@@@@@@@@@
(Thursday, 26. April 2018) 

What is new:
1. [Added] - Import Cmd parameter support (it simplifies the Import Process to multiple computers)

@@@@@@@@@@@@@@@@@@@@--RunAsTool v1.2--@@@@@@@@@@@@@@@@@@@@
(Friday, 09. February 2018) 

What is new:
1. [Fixed] - Shortcut problem
2. [Fixed] - Minor BUGs 
3. [Added] - x64 Version

@@@@@@@@@@@@@@@@@@@@--RunAsTool v1.1--@@@@@@@@@@@@@@@@@@@@
(Friday, 26. January 2018) 

What is new:
1. [Fixed] - Edit Mode does not allow it's fields to be filled via paste (ctrl-v)
2. [Fixed] - An Application file can be add only once into the list
3. [Fixed] - Edit Mode interface
4. [Fixed] - Import / Export Feature
5. [Fixed] - Minor BUGs
6. [Added] - Listed items positions can be changed via drag and drop (on top of each other)


@@@@@@@@@@@@@@@@@@@@--RunAsTool v1.0--@@@@@@@@@@@@@@@@@@@@
(October 12, 2015) 

Features:
RunAsTool is portable freeware which allows standard users to run a specific 
program with administrator privileges without the need to enter the administrator password. 
This allows you to provide standard (non-admin) users with access to programs that require admin rights.