Author: BlueLife ,Velociraptor
www.sordum.org

@@@@@@@@@@@@@@@@@@@@--ReIcon v1.9--@@@@@@@@@@@@@@@@@@@@
(Friday 25. September 2018)

- [Fixed] Delete key issue when renaming
- [Fixed] After clicking restore button,Disable Auto arrange mark doesn't change
- [Fixed] After update ReIcon version,Restore Icon layout on Right click may use old version
- [Fixed] A minor Cmd bug
- [Added] Changing Sort order via drag & Drop
- [Added] Some code improvements

@@@@@@@@@@@@@@@@@@@@--ReIcon v1.8--@@@@@@@@@@@@@@@@@@@@
(Friday 12. January 2018)

- [Fixed] Resolution information BUG
- [Fixed] ReIcon Add Context Menu for My Computer not working properly
- [Added] Some minor code improvements

@@@@@@@@@@@@@@@@@@@@--ReIcon v1.7--@@@@@@@@@@@@@@@@@@@@
(Thursday 18. March 2016)

- [Fixed] Windows 10 context menu BUG
- [Fixed] shortcut in startup folder BUG
- [Fixed] Button effect changed
- [Fixed] Some minor Bugs

@@@@@@@@@@@@@@@@@@@@--ReIcon v1.6--@@@@@@@@@@@@@@@@@@@@
(Monday 25. May 2015)

- [Fixed] After using ReIcon with Cmd , GUI doesn't detect changes
- [ADDED] Add /Delete ReIcon shotrcut into the startup folder feature
- [ADDED] Use Shift key to display Context Menu feature
- [ADDED] Add only Restore option to the Context menu feature
- [ADDED] Backup / Restore with ID , you can also use this command to overwrite existing profile (Cmd)
- [ADDED] Define save path with parameter and ID (Cmd)

@@@@@@@@@@@@@@@@@@@@--ReIcon v1.5--@@@@@@@@@@@@@@@@@@@@
(Tuesday , 27. January 2015)

- [Fixed] ReIcon fails to restore desktop layout if an icon name contains "[ ]" , "=" , ";" characters
- [Fixed] Some minor Bugs 
- [ADDED] Ctrl + A Shortcut (to select all Icon layout)


@@@@@@@@@@@@@@@@@@@@--ReIcon v1.4--@@@@@@@@@@@@@@@@@@@@
(Friday , 19. September 2014)

- [Added] Translate GUI
- And some code impovements

@@@@@@@@@@@@@@@@@@@@--ReIcon v1.3--@@@@@@@@@@@@@@@@@@@@
(Tuesday , 03. June 2014)

- [Fixed] If ReIcon runs as Administrator (Under restricted Account), saved Icon Layout's detail name is wrong 
- [Fixed] If ReIcon runs as Administrator (Under restricted Account), Show hidden Files doesn't work
- [Fixed] If ReIcon runs as Administrator (Under restricted Account), Show Files extension doesn't work
- [Fixed] Some minor Bugs

@@@@@@@@@@@@@@@@@@@@--ReIcon v1.2--@@@@@@@@@@@@@@@@@@@@
(Monday , 23. December 2013)

- [Fixed] Doesn't work on Windows 8.1 x64 Enterprise (If you click on �Save Icon�s-Layout�, nothing new appears in the list)
- [Fixed] Some minor Bugs
- [Added] Export - Import Feature
- [Added] Multiple Selection with the Keyboard
- [Added] Context menu creates It's own iconlayouts.ini and uses "user's name" as file name
- [Added] Uninstall Context menu doesn't delete iconlayouts.ini
- [Added] Context Menu install directory changed
- Dual Monitor support �mproved

@@@@@@@@@@@@@@@@@@@@--ReIcon v1.1--@@@@@@@@@@@@@@@@@@@@
(Sunday , 15. December 2013)

- [Fixed] False positive Issue
- [Fixed] A minor Bug about Right click (Context) menu

@@@@@@@@@@@@@@@@@@@@--ReIcon v1.0--@@@@@@@@@@@@@@@@@@@@
(Tuesday, 10. December 2013)

- Save your favorite icon's Layout for each screen resolution
- you can save many Icon's layout
- No need installation
- Unicode Support
- You can easily add "Save / restore Icon's Layout" feature in the Context menu
- Cmd support (ReIcon /?)
- Align icons to Grid feature - allows you to bring icons into proper position (similar to Windows Auto Range Icons feature)


